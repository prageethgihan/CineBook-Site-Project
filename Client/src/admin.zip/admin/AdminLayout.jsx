import { NavLink, Outlet, useLocation } from "react-router-dom";
import { useMemo } from "react";
import { useAuth } from "../auth/AuthContext";
import "./admin.css";

function SideLink({ to, icon, label }) {
  return (
    <NavLink
      to={to}
      end={to === "/admin"}
      className={({ isActive }) =>
        `admin-link d-flex align-items-center gap-2 admin-btn ${isActive ? "active" : ""}`
      }
    >
      <span className="admin-nav-ico" aria-hidden="true">
        {icon}
      </span>
      <span className="admin-nav-text">{label}</span>
    </NavLink>
  );
}

function getTitle(pathname) {
  if (pathname === "/admin") return "Dashboard";
  if (pathname.startsWith("/admin/movies")) return "Movies";
  if (pathname.startsWith("/admin/halls")) return "Halls";
  if (pathname.startsWith("/admin/shows")) return "Shows";
  if (pathname.startsWith("/admin/bookings")) return "Bookings";
  return "Admin";
}

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const location = useLocation();

  const pageTitle = useMemo(() => getTitle(location.pathname), [location.pathname]);

  return (
    <div className="admin-shell">
      <div className="admin-wrap d-flex">
        {/* Desktop Sidebar */}
        <aside className="admin-sidebar d-none d-lg-flex flex-column p-3">
          <div className="glass-card p-3 mb-3">
            <div className="d-flex align-items-start justify-content-between">
              <div className="me-2">
                <div className="fw-bold">🎬 Cinema Admin</div>
                <div className="small admin-muted text-truncate" style={{ maxWidth: 180 }}>
                  {user?.email}
                </div>
              </div>
              <span className="admin-badge">ADMIN</span>
            </div>
          </div>

          <nav className="d-flex flex-column gap-2">
            <SideLink to="/admin" icon="📊" label="Dashboard" />
            <SideLink to="/admin/movies" icon="🎞️" label="Movies" />
            <SideLink to="/admin/halls" icon="🏛️" label="Halls" />
            <SideLink to="/admin/shows" icon="🕒" label="Shows" />
            <SideLink to="/admin/bookings" icon="🎟️" label="Bookings" />
          </nav>

          <div className="mt-auto pt-3">
            <button className="btn btn-danger w-100 rounded-4" onClick={logout}>
              Logout
            </button>
          </div>
        </aside>

        {/* Mobile Topbar */}
        <header className="admin-topbar d-lg-none">
          <div className="container-fluid px-3">
            <div className="d-flex align-items-center justify-content-between py-3">
              <button
                className="btn btn-outline-light rounded-4"
                type="button"
                data-bs-toggle="offcanvas"
                data-bs-target="#adminSidebarCanvas"
                aria-controls="adminSidebarCanvas"
              >
                ☰
              </button>

              <div className="text-center">
                <div className="fw-semibold text-white">{pageTitle}</div>
                <div className="small admin-muted text-truncate" style={{ maxWidth: 220 }}>
                  {user?.email}
                </div>
              </div>

              <span className="admin-badge">ADMIN</span>
            </div>
          </div>
        </header>

        {/* Mobile Sidebar Offcanvas */}
        <div
          className="offcanvas offcanvas-start admin-offcanvas text-bg-dark"
          tabIndex="-1"
          id="adminSidebarCanvas"
          aria-labelledby="adminSidebarCanvasLabel"
        >
          <div className="offcanvas-header">
            <div>
              <div className="fw-bold" id="adminSidebarCanvasLabel">
                🎬 Cinema Admin
              </div>
              <div className="small admin-muted">{user?.email}</div>
            </div>

            <button
              type="button"
              className="btn-close btn-close-white"
              data-bs-dismiss="offcanvas"
              aria-label="Close"
            />
          </div>

          <div className="offcanvas-body d-flex flex-column gap-2">
            <SideLink to="/admin" icon="📊" label="Dashboard" />
            <SideLink to="/admin/movies" icon="🎞️" label="Movies" />
            <SideLink to="/admin/halls" icon="🏛️" label="Halls" />
            <SideLink to="/admin/shows" icon="🕒" label="Shows" />
            <SideLink to="/admin/bookings" icon="🎟️" label="Bookings" />

            <div className="mt-auto pt-3">
              <button className="btn btn-danger w-100 rounded-4" onClick={logout}>
                Logout
              </button>
            </div>
          </div>
        </div>

        {/* Main */}
        <main className="admin-main flex-grow-1">
          <div className="container-fluid p-3 p-lg-4">
            {/* Page Header (same design on every page) */}
            <div className="glass-card p-3 p-lg-4 mb-3 mb-lg-4">
              <div className="d-flex flex-wrap align-items-start justify-content-between gap-2">
                <div>
                  <div className="fw-semibold text-white">{pageTitle}</div>
                  <div className="small admin-muted">
                    Manage movies, halls, shows, and bookings in real time.
                  </div>
                </div>
                <span className="admin-badge">Real-time Booking System</span>
              </div>
            </div>

            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
